(function(){
    'use strict';

    alert('Hello World');
    /*% if (feature.featureA) { */alert('Feature A');/*% } */
})();
