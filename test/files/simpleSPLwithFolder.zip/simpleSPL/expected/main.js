(function(){
    'use strict';

    alert('Hello World');
    alert('Feature A');
})();
