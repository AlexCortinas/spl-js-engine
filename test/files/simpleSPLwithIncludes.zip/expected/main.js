(function(){
    'use strict';

    alert('Hello World');
    alert('Feature A');
    alert('aaa');
    alert('bbb');
    alert('ccc');
    alert('ddd');
    alert('eee');
    alert('fff');
})();
