package es.lbd.lps.calculator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyCalculatorApplication {

    public static void main(String[] args) {
        SpringApplication.run(MyCalculatorApplication.class, args);
    }
}
