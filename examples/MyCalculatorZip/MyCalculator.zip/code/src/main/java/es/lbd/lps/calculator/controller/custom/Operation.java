package es.lbd.lps.calculator.controller.custom;

public enum Operation {
    /*% if (feature.add) { %*/ADD,    /*% } if (feature.subtract) { %*/
    SUBTRACT,     /*% } if (feature.multiply) { %*/
    MULTIPLY,     /*% } if (feature.divide) { %*/
    DIVIDE  /*% } %*/
}
