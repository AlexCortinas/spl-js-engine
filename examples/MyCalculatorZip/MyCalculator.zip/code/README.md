#MyCalculator

Annotated source of a absurd web calculator to generate with *spl-js-engine* tool.

Once generated, it can be run with JAVA_HOME pointing to Java 8 and:

* npm install
* mvn spring-boot:run
